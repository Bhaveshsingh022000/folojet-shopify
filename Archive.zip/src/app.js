import '@shopify/shopify-api/adapters/node';
import {shopifyApi, ApiVersion, Session, DataType} from '@shopify/shopify-api';
import express from 'express';
const app = express();
const shopify = shopifyApi({
  // The next 4 values are typically read from environment variables for added security
  apiKey: '7f2f7fb0ffd9670eb8e100c22cd8c307',
  apiSecretKey: '184083bfaee2172141f8ea289cc37967',
  scopes: ['unauthenticated_read_product_listings'],
  apiVersion: ApiVersion.October23,
//   hostName: 'ngrok-tunnel-address',
//   apiVersion: LATEST_API_VERSION,
  hostName: 'localhost:3000',
  isEmbeddedApp: true,

//   isCustomStoreApp: true,
});

app.get('/', async (req, res) => {
  console.log("here")
  try{
    const code = req.query.code;
    console.log(req.query);
  await shopify.auth.begin({
      shop: shopify.utils.sanitizeShop(req.query.shop, true),
      callbackPath: '/auth/callback',
      isOnline: false,
      rawRequest: req,
      rawResponse: res,

  });}
  catch(e){
      console.log(e)
  }
});

const sessionId = shopify.session.getOfflineId('folojet-dev-store.myshopify.com')
const session = new Session({
  id: sessionId,
  shop: 'folojet-dev-store.myshopify.com',
  state: 'state',
  isOnline: false,
  accessToken: '4624e4f94d69586bcb7925805d6a539a6b767ec048782c8eb00ef6990073322a'
})




const storefrontAccessToken = "380328fa7ec72841daddfd2897eec5d3";

  const shop = 'folojet-dev-store.myshopify.com';

  const storefrontClient = new shopify.clients.Storefront({
    domain: shop,
    storefrontAccessToken,
    session
  });


  app.use(async(req,res)=>{
      const products = await storefrontClient.query({
        data: `{
          products (first: 3) {
            edges {
              node {
                id
                title
              }
            }
          }
        }`,
      });
    console.log("===========>", products)
    res.send(products);
  })

app.listen(3000);
